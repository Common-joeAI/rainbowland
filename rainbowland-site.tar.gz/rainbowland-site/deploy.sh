#!/bin/bash
# Deploy rainbowland.cc landing site to VPS
# Run from Tower2 or locally: bash deploy.sh

VPS_IP="107.199.175.81"
VPS_USER="root"
SITE_DIR="/var/www/rainbowland.cc"

echo "🌈 Deploying Rainbow Land landing site to $VPS_IP..."

# Create dir on VPS
ssh $VPS_USER@$VPS_IP "mkdir -p $SITE_DIR"

# Sync files (exclude worker — deployed to Cloudflare separately)
rsync -avz --delete \
  --exclude 'cloudflare-worker' \
  --exclude 'deploy.sh' \
  ./ $VPS_USER@$VPS_IP:$SITE_DIR/

# Set up nginx if not already configured
ssh $VPS_USER@$VPS_IP "
if [ ! -f /etc/nginx/sites-available/rainbowland.cc ]; then
  cat > /etc/nginx/sites-available/rainbowland.cc << 'NGINX'
server {
    listen 80;
    server_name rainbowland.cc www.rainbowland.cc;
    root /var/www/rainbowland.cc;
    index index.html;

    # Security headers
    add_header X-Frame-Options SAMEORIGIN;
    add_header X-Content-Type-Options nosniff;
    add_header Referrer-Policy strict-origin-when-cross-origin;
    add_header Permissions-Policy 'camera=(), microphone=(), geolocation=()';

    # Cache static assets
    location ~* \.(css|js|png|jpg|svg|ico|woff2)$ {
        expires 30d;
        add_header Cache-Control 'public, immutable';
    }

    location / {
        try_files \$uri \$uri/ \$uri.html =404;
    }

    error_page 404 /404.html;
}
NGINX
  ln -sf /etc/nginx/sites-available/rainbowland.cc /etc/nginx/sites-enabled/
  nginx -t && systemctl reload nginx
  echo '✅ Nginx configured'
fi

# SSL via certbot
if [ ! -d /etc/letsencrypt/live/rainbowland.cc ]; then
  certbot --nginx -d rainbowland.cc -d www.rainbowland.cc --non-interactive --agree-tos -m support@rainbowland.cc
  echo '✅ SSL certificate issued'
fi

nginx -t && systemctl reload nginx
echo '✅ Site live at https://rainbowland.cc'
"
