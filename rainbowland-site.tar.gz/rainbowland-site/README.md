# rainbowland.cc — Landing Site

Static landing page for the Rainbow Land desktop streaming app.

## Structure
```
index.html          — Main landing page
privacy.html        — Privacy Policy (TikTok-compliant)
terms.html          — Terms of Service
support.html        — Support center + contact form
styles.css          — Shared CSS (dark theme, pride colors)
cloudflare-worker/  — Cloudflare Worker for contact form email forwarding
deploy.sh           — Deploy to VPS via rsync + nginx
```

## Deploy to VPS
```bash
bash deploy.sh
```

## Cloudflare Worker Setup (contact form → Gmail)

1. Go to **dash.cloudflare.com → Workers & Pages → Create Worker**
2. Paste contents of `cloudflare-worker/support-worker.js`
3. Name it `support-worker`
4. Add Environment Variables:
   - `TO_EMAIL` = `support@rainbowland.cc`
   - `FROM_EMAIL` = `noreply@rainbowland.cc`
   - `ALLOWED_ORIGIN` = `https://rainbowland.cc`
5. Add Custom Domain: `support-worker.rainbowland.cc`

## Cloudflare Email Routing (support@rainbowland.cc → Gmail)

1. Cloudflare Dashboard → rainbowland.cc → **Email → Email Routing**
2. Click **Enable Email Routing**
3. Add rule:
   - **From:** `support@rainbowland.cc`
   - **Action:** Send to → `your-gmail@gmail.com`
4. Cloudflare will add the required MX records automatically

## TikTok Developer App Requirements Met

- ✅ Public landing page at rainbowland.cc
- ✅ Privacy Policy at rainbowland.cc/privacy with TikTok-specific section
- ✅ Terms of Service at rainbowland.cc/terms with TikTok section
- ✅ Support contact at support@rainbowland.cc
- ✅ App description clearly explains functionality
- ✅ No data collection from TikTok users documented
