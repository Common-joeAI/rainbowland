/**
 * Cloudflare Worker — Rainbow Land Support Email Forwarder
 *
 * Deploy this at: support-worker.rainbowland.cc
 *
 * SETUP STEPS:
 * 1. Go to dash.cloudflare.com → Workers & Pages → Create Worker
 * 2. Paste this code
 * 3. Add these Environment Variables (Settings → Variables):
 *    - MAILCHANNELS_API_KEY  (get free key at mailchannels.com)
 *    - TO_EMAIL              support@rainbowland.cc
 *    - FROM_EMAIL            noreply@rainbowland.cc
 *    - ALLOWED_ORIGIN        https://rainbowland.cc
 * 4. Add route: support-worker.rainbowland.cc/* → this worker
 *
 * Cloudflare Email Routing must be configured separately:
 * Cloudflare Dashboard → rainbowland.cc → Email → Email Routing
 * Add: support@rainbowland.cc → forward to → your-gmail@gmail.com
 */

const ALLOWED_ORIGINS = [
  'https://rainbowland.cc',
  'https://www.rainbowland.cc',
  'http://localhost:3000',   // local dev
]

export default {
  async fetch(request, env) {

    // ── CORS preflight ──────────────────────────────────────
    const origin = request.headers.get('Origin') || ''
    const allowedOrigin = ALLOWED_ORIGINS.includes(origin)
      ? origin
      : ALLOWED_ORIGINS[0]

    const corsHeaders = {
      'Access-Control-Allow-Origin':  allowedOrigin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    }

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders })
    }

    // ── Route: POST /submit ─────────────────────────────────
    const url = new URL(request.url)
    if (request.method === 'POST' && url.pathname === '/submit') {

      let body
      try {
        body = await request.json()
      } catch {
        return new Response(JSON.stringify({ error: 'Invalid JSON' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
      }

      const { name, email, type, subject, message } = body

      // Basic validation
      if (!name || !email || !subject || !message) {
        return new Response(JSON.stringify({ error: 'Missing required fields' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
      }

      // Email length guard
      if (message.length > 10000) {
        return new Response(JSON.stringify({ error: 'Message too long' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
      }

      // Type label
      const typeLabels = {
        support: '🛠️ Support',
        feature: '💡 Feature Request',
        bug:     '🐛 Bug Report',
        tiktok:  '🎵 TikTok Integration',
        other:   '💬 Other',
      }
      const typeLabel = typeLabels[type] || type

      // ── Send via MailChannels (free on Cloudflare Workers) ──
      const emailPayload = {
        personalizations: [{
          to: [{ email: env.TO_EMAIL || 'support@rainbowland.cc' }],
          reply_to: { email, name },
        }],
        from: {
          email: env.FROM_EMAIL || 'noreply@rainbowland.cc',
          name:  'Rainbow Land Support',
        },
        subject: `[Rainbow Land] [${typeLabel}] ${subject}`,
        content: [
          {
            type:  'text/plain',
            value: [
              `From: ${name} <${email}>`,
              `Type: ${typeLabel}`,
              `Subject: ${subject}`,
              ``,
              `--- Message ---`,
              message,
              ``,
              `--- Submitted via rainbowland.cc/support ---`,
            ].join('\n'),
          },
          {
            type:  'text/html',
            value: `
              <div style="font-family:Inter,system-ui,sans-serif;max-width:600px;margin:0 auto;background:#0a0a12;color:#fff;border-radius:16px;overflow:hidden;">
                <div style="height:4px;background:linear-gradient(90deg,#FF3366,#FF7A00,#FFD700,#00E676,#00B4FF,#9B59FF);"></div>
                <div style="padding:32px;">
                  <h1 style="font-size:1.4rem;margin-bottom:4px;">🌈 Rainbow Land Support</h1>
                  <p style="color:#9B59FF;font-size:0.85rem;margin-bottom:28px;">${typeLabel}</p>

                  <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
                    <tr><td style="padding:8px 0;color:rgba(255,255,255,0.4);font-size:0.8rem;width:80px;">From</td><td style="padding:8px 0;font-weight:600;">${name}</td></tr>
                    <tr><td style="padding:8px 0;color:rgba(255,255,255,0.4);font-size:0.8rem;">Email</td><td style="padding:8px 0;"><a href="mailto:${email}" style="color:#9B59FF;">${email}</a></td></tr>
                    <tr><td style="padding:8px 0;color:rgba(255,255,255,0.4);font-size:0.8rem;">Type</td><td style="padding:8px 0;">${typeLabel}</td></tr>
                    <tr><td style="padding:8px 0;color:rgba(255,255,255,0.4);font-size:0.8rem;">Subject</td><td style="padding:8px 0;font-weight:600;">${subject}</td></tr>
                  </table>

                  <div style="background:rgba(255,255,255,0.04);border-radius:12px;padding:20px;border:1px solid rgba(255,255,255,0.07);">
                    <p style="color:rgba(255,255,255,0.4);font-size:0.75rem;margin-bottom:12px;text-transform:uppercase;letter-spacing:0.08em;">Message</p>
                    <p style="color:rgba(255,255,255,0.85);line-height:1.7;white-space:pre-wrap;">${message.replace(/</g,'&lt;').replace(/>/g,'&gt;')}</p>
                  </div>

                  <p style="margin-top:28px;font-size:0.8rem;color:rgba(255,255,255,0.3);">
                    Submitted via <a href="https://rainbowland.cc/support" style="color:#9B59FF;">rainbowland.cc/support</a>
                    · Reply directly to this email to respond to ${name}
                  </p>
                </div>
              </div>
            `,
          }
        ],
      }

      const mailRes = await fetch('https://api.mailchannels.net/tx/v1/send', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(emailPayload),
      })

      if (mailRes.ok || mailRes.status === 202) {
        return new Response(JSON.stringify({ ok: true }), {
          status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
      } else {
        const errText = await mailRes.text()
        console.error('MailChannels error:', mailRes.status, errText)
        return new Response(JSON.stringify({ error: 'Email delivery failed' }), {
          status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
      }
    }

    return new Response('Not found', { status: 404, headers: corsHeaders })
  }
}
